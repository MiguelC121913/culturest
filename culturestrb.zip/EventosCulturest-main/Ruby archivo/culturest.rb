require 'csv'
require 'json'
require 'sqlite3'
require 'builder'

class Attendee
  attr_accessor :name, :email

  def initialize(name, email)
    @name = name
    @email = email
  end
end

module EventRegistration
  FILE_PATH = "attendees.hta"

  def self.register(name, email)
    attendee = Attendee.new(name, email)
    File.open(FILE_PATH, 'a') do |file|
      file.puts("#{attendee.name}, #{attendee.email}")
    end
    puts "Alumno #{attendee.name} registrado correctamente!"
  end
end

module ExportFormats
  FILE_PATH = "attendees"

  def self.export_to_csv(attendees)
    CSV.open("#{FILE_PATH}.csv", "w") do |csv|
      csv << ["Name", "Email"]
      attendees.each do |attendee|
        csv << [attendee.name, attendee.email]
      end
    end
    puts "Exported alumnos to CSV successfully!"
  end

  def self.export_to_sql(attendees)
    db = SQLite3::Database.new("#{FILE_PATH}.sqlite3")
    db.execute("CREATE TABLE IF NOT EXISTS attendees (name TEXT, email TEXT)")
    attendees.each do |attendee|
      db.execute("INSERT INTO attendees (name, email) VALUES (?, ?)", [attendee.name, attendee.email])
    end
    db.close
    puts "Exported alumnos to SQLite database successfully!"
  end

  def self.export_to_json(attendees)
    attendees_json = attendees.map { |attendee| { name: attendee.name, email: attendee.email } }
    File.open("#{FILE_PATH}.json", "w") do |file|
      file.write(JSON.pretty_generate(attendees_json))
    end
    puts "Exported alumnos to JSON successfully!"
  end

  def self.export_to_xml(attendees)
    xml = Builder::XmlMarkup.new(indent: 2)
    xml.attendees do
      attendees.each do |attendee|
        xml.attendee do
          xml.name attendee.name
          xml.email attendee.email
        end
      end
    end
    File.open("#{FILE_PATH}.xml", "w") { |file| file.write(xml.target!) }
    puts "Exported alumnos to XML successfully!"
  end
end

# Ejemplo de uso:
EventRegistration.register("John Lopez", "john@example.com")
EventRegistration.register("Jane Lopez", "jane@example.com")

attendees = [
  Attendee.new("John Lopez", "john@example.com"),
  Attendee.new("Jane Lopez", "jane@example.com")
]

ExportFormats.export_to_csv(attendees)
ExportFormats.export_to_sql(attendees)
ExportFormats.export_to_json(attendees)
ExportFormats.export_to_xml(attendees)
